package com.practice.pages;

public class MainActivityImpl extends MainActivity {
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
}
