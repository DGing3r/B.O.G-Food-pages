package com.practice.pages;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

}